#Creating clock using Python <33!

from cProfile import label
from tkinter import *
from tkinter.ttk import *

from time import strftime

root = Tk()
root.title("Clock ni Laurence") #this is the title of the window "Clock ni Laurence"

def time():
    string = strftime ('%H:%M:%S %p')
    label.config(text=string)
    label.after(1000, time)

label = Label(root, font=("ds-digital", 90), background = "beige", foreground = "black")

label.pack(anchor = 'center') # I center as the text anchor to make the text horizonlly
                                    # and vertically around the reference point.        
                                                       
time() # this time molude is used to get the time in SECONDS.
mainloop()