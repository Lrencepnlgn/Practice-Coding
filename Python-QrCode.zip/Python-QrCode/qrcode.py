import pyqrcode
from pyzbar.pyzbar import decode
from PIL import Image

qr = pyqrcode.create("My Facebook Name: Laurence Mendoza Panaligan\n"
                     "My Instagram Name: Laurencepnlgn\n"
                     "My Github Name: Laurencepnlgn")
qr.png("myQrCode.png", scale = 8)

d = decode(Image.open("myQrCode.png"))
print(d[0].data.decode("ascii"))